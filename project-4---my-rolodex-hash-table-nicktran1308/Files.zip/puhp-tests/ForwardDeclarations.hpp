
#ifndef PUHP_TESTS_FORWARD_DECLARATIONS_HPP
#define PUHP_TESTS_FORWARD_DECLARATIONS_HPP

//
namespace PuhPTests
{
	//	Nada
}

#endif
